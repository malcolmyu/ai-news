# 第二号更新器 (Second Number Updater)

整合"第二号"数字分身的三大更新能力：AI 日报、调研报告、主页更新。

## 目录结构

```
second-number-updater/
├── SKILL.md              # 本文档
├── run.py                # 主程序入口
└── skills/               # 子 skill 目录
    ├── daily/            # AI 日报生成
    │   ├── run.py
    │   └── data/         # 数据存储
    ├── research/         # 调研报告管理
    │   └── run.py
    └── homepage/         # 主页更新
        └── run.py
```

## 使用方法

```bash
cd ~/.openclaw/skills/second-number-updater
python3 run.py <command>
```

### 命令

| 命令 | 说明 | 示例 |
|------|------|------|
| `daily` | 生成并推送今天的 AI 日报 | `python3 run.py daily` |
| `research <file>` | 添加调研报告到首页 | `python3 run.py research report.html` |
| `homepage` | 更新主页内容 | `python3 run.py homepage` |
| `all` | 执行全部更新 | `python3 run.py all` |
| `help` | 显示帮助 | `python3 run.py help` |

## 子 Skill 详情

### 1. daily - AI 日报生成

**位置:** `skills/daily/run.py`

**功能:**
- 从 23+ 个 RSS 信源抓取 AI 资讯
- 生成 AI 总结（使用 Gemini）
- 生成分类 HTML 报告
- 更新历史归档页面

**输出:**
- `docs/ai-daily-YYYY-MM-DD.html`
- `docs/ai-daily-latest.html`
- `docs/ai-daily-archive.html`

### 2. research - 调研报告管理

**位置:** `skills/research/run.py`

**功能:**
- 将调研报告添加到首页"深度调研报告"栏目
- 自动提取报告标题和摘要
- 更新报告归档页面

**使用:**
```bash
python3 run.py research harness-engineering-deep-dive.html
```

### 3. homepage - 主页更新

**位置:** `skills/homepage/run.py`

**功能:**
- 更新主页统计数据
- 更新日报预览
- 维护首页链接

## 配置

**全局配置:**
- `DOCS_DIR`: `~/.openclaw/workspace/docs`
- `SOURCES_FILE`: `~/.openclaw/workspace/ai-insight-sources-full.json`

**子 skill 独立配置:**
- daily: `skills/daily/data/` (数据缓存)

## 开发新子 Skill

1. 在 `skills/` 下创建新目录
2. 添加 `run.py` 作为入口
3. 在主 `run.py` 中注册子 skill 路径
4. 添加对应的命令处理函数

## 依赖

- Python 3.8+
- Gemini CLI (用于 AI 总结)
- Git (用于推送)

## 相关技能

- `ai-daily-tracker` - 已整合到本 skill 的 daily 子 skill
- `harness-check` - 独立的 Harness 工程检查 skill
