#!/usr/bin/env python3
"""
第二号更新器 - 主程序
整合三大更新能力：AI日报、调研报告、主页
"""

import subprocess
import sys
from pathlib import Path
from datetime import datetime

# 子 skill 目录
SKILL_DIR = Path(__file__).parent
SUB_SKILLS = {
    "daily": SKILL_DIR / "skills" / "daily" / "run.py",
    "research": SKILL_DIR / "skills" / "research" / "run.py",
    "homepage": SKILL_DIR / "skills" / "homepage" / "run.py",
}

# Docs 目录
DOCS_DIR = Path.home() / ".openclaw/workspace/docs"


def run_subskill(name: str, *args) -> bool:
    """运行子 skill"""
    if name not in SUB_SKILLS:
        print(f"⚠️  未知子 skill: {name}")
        return False
    
    skill_path = SUB_SKILLS[name]
    if not skill_path.exists():
        print(f"⚠️  子 skill 不存在: {skill_path}")
        return False
    
    cmd = ["python3", str(skill_path)] + list(args)
    result = subprocess.run(cmd, capture_output=True, text=True)
    
    print(result.stdout)
    if result.stderr:
        print("⚠️  错误:", result.stderr)
    
    return result.returncode == 0


def push_to_git(message: str) -> bool:
    """推送到 GitHub"""
    print("\n" + "="*60)
    print("📤 推送到 GitHub")
    print("="*60)
    
    workspace = Path.home() / ".openclaw/workspace"
    
    try:
        # 添加变更
        subprocess.run(
            ["git", "add", "docs/"],
            cwd=workspace,
            check=True
        )
        
        # 检查是否有变更
        result = subprocess.run(
            ["git", "diff", "--cached", "--quiet"],
            cwd=workspace
        )
        
        if result.returncode == 0:
            print("ℹ️  没有变更需要提交")
            return True
        
        # 提交
        subprocess.run(
            ["git", "commit", "-m", message],
            cwd=workspace,
            check=True
        )
        print(f"✓ 已提交: {message}")
        
        # 推送
        result = subprocess.run(
            ["git", "push", "origin", "HEAD"],
            cwd=workspace,
            capture_output=True,
            text=True
        )
        
        if result.returncode == 0:
            print("✓ 已推送到 GitHub")
            return True
        else:
            print(f"⚠️  推送失败: {result.stderr}")
            return False
            
    except Exception as e:
        print(f"⚠️  Git 操作失败: {e}")
        return False


def cmd_daily():
    """生成 AI 日报"""
    if run_subskill("daily"):
        push_to_git(f"📰 AI Daily: {datetime.now().strftime('%Y-%m-%d')}")


def cmd_research(report_file: str = None):
    """添加调研报告"""
    if not report_file:
        print("⚠️  请提供报告文件名")
        print("  示例: python3 run.py research my-report.html")
        return
    
    if run_subskill("research", report_file):
        push_to_git(f"📊 Research: {report_file}")


def cmd_homepage():
    """更新主页"""
    if run_subskill("homepage"):
        push_to_git("🏠 Update homepage")


def cmd_all():
    """执行全部更新"""
    print("\n" + "="*60)
    print("🚀 执行全部更新")
    print("="*60)
    
    # 1. AI 日报
    daily_success = run_subskill("daily")
    
    # 2. 主页
    homepage_success = run_subskill("homepage")
    
    # 3. 推送
    if daily_success or homepage_success:
        push_to_git(f"🚀 Second Number Update: {datetime.now().strftime('%Y-%m-%d')}")
    
    print("\n" + "="*60)
    print("✅ 全部更新完成")
    print("="*60)


def show_help():
    """显示帮助"""
    print("""
第二号更新器 - 使用方法

python3 run.py <command> [args]

命令:
  daily              生成并推送今天的 AI 日报
  homepage           更新主页内容
  research <file>    添加调研报告到首页
  all                执行全部更新
  help               显示此帮助

子 skill 结构:
  skills/
  ├── daily/         AI 日报生成
  │   └── run.py
  ├── research/      调研报告管理
  │   └── run.py
  └── homepage/      主页更新
      └── run.py

示例:
  python3 run.py daily
  python3 run.py research harness-report.html
  python3 run.py all
    """)


def main():
    """主函数"""
    if len(sys.argv) < 2:
        show_help()
        return
    
    command = sys.argv[1].lower()
    
    if command in ("help", "-h", "--help"):
        show_help()
    elif command == "daily":
        cmd_daily()
    elif command == "homepage":
        cmd_homepage()
    elif command == "research":
        report_file = sys.argv[2] if len(sys.argv) > 2 else None
        cmd_research(report_file)
    elif command == "all":
        cmd_all()
    else:
        print(f"⚠️  未知命令: {command}")
        show_help()


if __name__ == "__main__":
    main()
