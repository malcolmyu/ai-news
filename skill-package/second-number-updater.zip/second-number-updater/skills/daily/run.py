#!/usr/bin/env python3
"""
AI 日报子 Skill - Auckland 版本适配器
调用 src/main.py 生成日报，并更新归档
"""

import subprocess
import sys
import re
import shutil
from pathlib import Path
from datetime import datetime

# 路径配置
SKILL_DIR = Path(__file__).parent
DOCS_DIR = Path.home() / ".openclaw/workspace/docs"
OUTPUT_DIR = SKILL_DIR / "output"


def update_archive_page(date_str: str, article_count: int):
    """更新归档页面 - 同一天只保留最新一篇"""
    try:
        archive_path = DOCS_DIR / "ai-daily-archive.html"
        if not archive_path.exists():
            print(f"  ⚠️  归档页面不存在: {archive_path}")
            return
        
        with open(archive_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        date_obj = datetime.strptime(date_str, "%Y-%m-%d")
        display_date = date_obj.strftime("%Y年%m月%d日")
        
        new_entry = f'''    {{
        "date": "{display_date}",
        "file": "ai-daily-{date_str}.html",
        "articles": {article_count}
    }}'''
        
        # 检查是否已有同一天的条目
        date_pattern = rf'{{[^}}]*"date":\s*"{display_date}"[^}}]*}}'
        existing_match = re.search(date_pattern, content)
        
        if existing_match:
            # 替换已有条目
            new_content = content[:existing_match.start()] + new_entry + content[existing_match.end():]
            print(f"  ✓ 已更新当天归档: {display_date}")
        else:
            # 添加新条目到开头
            match = re.search(r'(const archives = \[)', content)
            if match:
                insert_pos = match.end()
                if content[insert_pos:insert_pos+1] == ']':
                    new_content = content[:insert_pos] + '\n' + new_entry + '\n' + content[insert_pos:]
                else:
                    new_content = content[:insert_pos] + '\n' + new_entry + ',' + content[insert_pos:]
                print(f"  ✓ 已添加新归档: {display_date}")
            else:
                print(f"  ⚠️  未找到 archives 数组")
                return
        
        with open(archive_path, 'w', encoding='utf-8') as f:
            f.write(new_content)
            
    except Exception as e:
        print(f"  ⚠️  更新归档失败: {e}")


def copy_to_docs(date_str: str):
    """复制生成的文件到 docs 目录"""
    try:
        # 源文件
        src_file = OUTPUT_DIR / f"ai-news-{date_str}.html"
        if not src_file.exists():
            print(f"  ⚠️  源文件不存在: {src_file}")
            return False
        
        # 确保 docs 目录存在
        DOCS_DIR.mkdir(parents=True, exist_ok=True)
        
        # 复制到 docs，重命名为 ai-daily-YYYY-MM-DD.html
        dst_file = DOCS_DIR / f"ai-daily-{date_str}.html"
        shutil.copy2(src_file, dst_file)
        print(f"  ✓ 已复制到: {dst_file}")
        
        # 同时创建 latest 版本
        latest_file = DOCS_DIR / "ai-daily-latest.html"
        shutil.copy2(src_file, latest_file)
        print(f"  ✓ 已更新: {latest_file}")
        
        return True
    except Exception as e:
        print(f"  ⚠️  复制文件失败: {e}")
        return False


def count_articles_in_html(html_path: Path) -> int:
    """统计 HTML 中的文章数量"""
    try:
        with open(html_path, 'r', encoding='utf-8') as f:
            content = f.read()
        # 统计 news-card 类数量
        return len(re.findall(r'class="news-card"', content))
    except:
        return 0


def run():
    """运行日报生成"""
    date_str = datetime.now().strftime("%Y-%m-%d")
    
    print(f"\n{'='*60}")
    print(f"🤖 AI 日报生成 (Auckland 版本)")
    print(f"{'='*60}")
    
    # 1. 运行主程序生成日报
    print("\n📡 开始抓取和生成...")
    result = subprocess.run(
        ["python3", "src/main.py", "--output", "output"],
        cwd=SKILL_DIR,
        capture_output=False
    )
    
    if result.returncode != 0:
        print("\n❌ 日报生成失败")
        return None
    
    # 2. 复制到 docs 目录
    print("\n📁 复制到 docs 目录...")
    if not copy_to_docs(date_str):
        return None
    
    # 3. 统计文章数
    html_file = DOCS_DIR / f"ai-daily-{date_str}.html"
    article_count = count_articles_in_html(html_file)
    
    # 4. 更新归档页面
    print("\n📚 更新历史日报归档...")
    update_archive_page(date_str, article_count)
    
    print(f"\n{'='*60}")
    print("✅ AI 日报生成完成!")
    print(f"{'='*60}\n")
    
    return date_str


if __name__ == "__main__":
    run()
