#!/usr/bin/env python3
"""
调研报告子 Skill
添加调研报告到首页
"""

import re
from pathlib import Path
from datetime import datetime

DOCS_DIR = Path.home() / ".openclaw/workspace/docs"


def extract_report_title(report_path: Path) -> str:
    """从报告文件中提取标题"""
    try:
        with open(report_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 尝试提取 <title>
        title_match = re.search(r'<title>(.*?)</title>', content, re.I)
        if title_match:
            return title_match.group(1).strip()
        
        # 尝试提取 <h1>
        h1_match = re.search(r'<h1[^>]*>(.*?)</h1>', content, re.I | re.S)
        if h1_match:
            return re.sub(r'<[^>]+>', '', h1_match.group(1)).strip()
        
        # 默认使用文件名
        return report_path.stem.replace('-', ' ').replace('_', ' ').title()
    except:
        return report_path.stem


def extract_report_summary(report_path: Path) -> str:
    """从报告文件中提取摘要"""
    try:
        with open(report_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 尝试提取 meta description
        desc_match = re.search(r'<meta[^\u003e]*name=["\']description["\'][^\u003e]*content=["\']([^"\']+)', content, re.I)
        if desc_match:
            return desc_match.group(1).strip()
        
        # 尝试提取第一段文字
        text_match = re.search(r'<p>([^<]+)</p>', content, re.I)
        if text_match:
            return text_match.group(1).strip()[:100]
        
        return "点击查看完整报告 →"
    except:
        return "点击查看完整报告 →"


def add_research_to_homepage(report_file: str, featured: bool = True) -> bool:
    """添加调研报告到首页"""
    print(f"\n📊 添加调研报告: {report_file}")
    
    report_path = DOCS_DIR / report_file
    if not report_path.exists():
        print(f"  ⚠️  报告文件不存在: {report_path}")
        return False
    
    index_path = DOCS_DIR / "index.html"
    if not index_path.exists():
        print(f"  ⚠️  首页不存在: {index_path}")
        return False
    
    with open(index_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 提取报告信息
    title = extract_report_title(report_path)
    summary = extract_report_summary(report_path)
    date_str = datetime.now().strftime("%Y-%m-%d")
    
    # 创建报告卡片 HTML
    card_class = "report-card featured" if featured else "report-card"
    new_card = f'''<a href="{report_file}" class="{card_class}">
                    <div class="report-header">
                        <span class="report-tag">最新</span>
                        <span class="report-date">{date_str}</span>
                    </div>
                    <h3 class="report-title">{title}</h3>
                    <p class="report-desc">{summary}</p>
                </a>'''
    
    # 查找深度调研报告区域
    # 查找 <div class="reports-grid"> 并插入新卡片
    pattern = r'(<div class="reports-grid">)'
    match = re.search(pattern, content)
    
    if match:
        insert_pos = match.end()
        new_content = content[:insert_pos] + '\n                ' + new_card + content[insert_pos:]
        
        with open(index_path, 'w', encoding='utf-8') as f:
            f.write(new_content)
        
        print(f"  ✓ 已添加到首页: {title}")
        return True
    else:
        print(f"  ⚠️  未找到 reports-grid 区域")
        return False


def update_research_archive(report_file: str) -> bool:
    """更新调研报告归档页面"""
    archive_path = DOCS_DIR / "research-archive.html"
    if not archive_path.exists():
        print(f"  ⚠️  归档页面不存在: {archive_path}")
        return False
    
    report_path = DOCS_DIR / report_file
    title = extract_report_title(report_path)
    date_str = datetime.now().strftime("%Y-%m-%d")
    
    try:
        with open(archive_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 创建新条目
        new_item = f'''    {{
        "date": "{date_str}",
        "title": "{title}",
        "file": "{report_file}"
    }}'''
        
        # 查找 archives 数组
        match = re.search(r'(const archives = \[)', content)
        if match:
            insert_pos = match.end()
            if content[insert_pos:insert_pos+1] == ']':
                new_content = content[:insert_pos] + '\n' + new_item + '\n' + content[insert_pos:]
            else:
                new_content = content[:insert_pos] + '\n' + new_item + ',' + content[insert_pos:]
            
            with open(archive_path, 'w', encoding='utf-8') as f:
                f.write(new_content)
            
            print(f"  ✓ 已更新归档页面")
            return True
    except Exception as e:
        print(f"  ⚠️  更新归档失败: {e}")
    
    return False


def run(report_file: str = None):
    """运行调研报告更新"""
    if not report_file:
        print("\n📊 调研报告更新")
        print("用法: python3 run.py <report_file.html>")
        return
    
    print(f"\n{'='*60}")
    print("📊 调研报告更新")
    print(f"{'='*60}")
    
    # 添加到首页
    if add_research_to_homepage(report_file, featured=True):
        # 更新归档
        update_research_archive(report_file)
        print(f"\n{'='*60}")
        print("✅ 调研报告更新完成!")
        print(f"{'='*60}\n")
    else:
        print(f"\n{'='*60}")
        print("⚠️ 更新失败")
        print(f"{'='*60}\n")


if __name__ == "__main__":
    import sys
    report_file = sys.argv[1] if len(sys.argv) > 1 else None
    run(report_file)
