#!/usr/bin/env python3
"""
AI 日报子 Skill
生成并推送每日 AI 资讯
"""

import json
import urllib.request
import re
import hashlib
import subprocess
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Dict, Optional

# 配置
OUTPUT_DIR = Path(__file__).parent / "output"
DATA_DIR = Path(__file__).parent / "data"
DOCS_DIR = Path.home() / ".openclaw/workspace/docs"
OUTPUT_DIR.mkdir(exist_ok=True)
DATA_DIR.mkdir(exist_ok=True)
DOCS_DIR.mkdir(exist_ok=True)

# 信源文件
SOURCES_FILE = Path.home() / ".openclaw/workspace/ai-insight-sources-full.json"


def load_sources() -> List[Dict]:
    """加载 RSS 信源"""
    try:
        with open(SOURCES_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        sources = []
        for rss in data.get('rss_sources', {}).get('verified', []):
            if rss.get('status') == 'active':
                sources.append({
                    'name': rss['name'],
                    'url': rss['url'],
                    'category': rss.get('category', 'general'),
                    'language': rss.get('language', 'en')
                })
        
        print(f"✓ 加载 {len(sources)} 个 RSS 信源")
        return sources
    except Exception as e:
        print(f"⚠️ 加载信源失败: {e}，使用默认信源")
        return [
            {"name": "宝玉(中文)", "url": "https://s.baoyu.io/feed.xml", "category": "newsletter", "language": "zh"},
            {"name": "OpenAI News", "url": "https://openai.com/news/rss.xml", "category": "official", "language": "en"},
            {"name": "Import AI", "url": "https://importai.substack.com/feed", "category": "newsletter", "language": "en"},
        ]


def fetch(url: str, timeout: int = 15) -> str:
    """获取 URL 内容"""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.read().decode("utf-8", errors="ignore")
    except:
        return ""


def parse_date(date_str: str) -> Optional[datetime]:
    """解析日期格式"""
    if not date_str:
        return None
    formats = ["%a, %d %b %Y %H:%M:%S %Z", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"]
    for fmt in formats:
        try:
            return datetime.strptime(date_str.strip()[:19], fmt)
        except:
            continue
    return None


def is_within_week(date_str: str) -> bool:
    """检查是否在一周内"""
    parsed = parse_date(date_str)
    if not parsed:
        return True
    week_ago = datetime.now() - timedelta(days=7)
    return parsed >= week_ago


def parse_rss(content: str, source: Dict, max_items: int = 3) -> List[Dict]:
    """解析 RSS"""
    items = []
    pattern = r"<(item|entry)[^>]*>(.*?)</\1>"
    matches = re.findall(pattern, content, re.S | re.I)
    
    for _, item_content in matches[:max_items]:
        title = re.search(rf"<title[^>]*>(.*?)</title>", item_content, re.S | re.I)
        link = re.search(rf"<link[^>]*>(.*?)</link>", item_content, re.S | re.I)
        date = re.search(rf"<(pubDate|published)[^>]*>(.*?)</\1>", item_content, re.S | re.I)
        summary = re.search(rf"<(description|summary)[^>]*>(.*?)</\1>", item_content, re.S | re.I)
        
        date_str = date.group(2) if date else ""
        if not is_within_week(date_str):
            continue
        
        if title:
            clean_summary = clean_html(summary.group(2) if summary else "")
            items.append({
                "source": source['name'],
                "title": clean_text(title.group(1)),
                "link": clean_text(link.group(1)) if link else "",
                "published": clean_text(date_str),
                "summary": clean_summary,
                "ai_summary": "",
                "source_category": source.get('category', 'general'),
                "id": hashlib.md5(f"{source['name']}:{title.group(1)}".encode()).hexdigest()[:12],
            })
    
    return items


def clean_text(text: str) -> str:
    """清理文本"""
    if not text:
        return ""
    text = re.sub(r"<!\[CDATA\[(.*?)\]\]>", r"\1", text, flags=re.S)
    text = text.replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&")
    text = text.replace("&quot;", '"').replace("&#8217;", "'").replace("&#8220;", '"').replace("&#8221;", '"')
    return " ".join(text.split())


def clean_html(html: str) -> str:
    """清理 HTML"""
    if not html:
        return ""
    text = re.sub(r"<style[^>]*>.*?</style>", " ", html, flags=re.S | re.I)
    text = re.sub(r"<script[^>]*>.*?</script>", " ", text, flags=re.S | re.I)
    text = re.sub(r"</?\w+[^>]*?>", " ", text, flags=re.S)
    text = clean_text(text)
    return " ".join(text.split())[:400]


def escape_html(text: str) -> str:
    """HTML 转义"""
    if not text:
        return ""
    return (text
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
            .replace("'", "&#x27;"))


def ai_summarize(title: str, content: str) -> str:
    """使用 Gemini 生成 AI 总结"""
    import hashlib
    
    cache_key = hashlib.md5(f"{title}:{content[:100]}".encode()).hexdigest()[:16]
    cache_file = DATA_DIR / f"summary_cache_{cache_key}.txt"
    
    if cache_file.exists():
        with open(cache_file, 'r', encoding='utf-8') as f:
            return f.read().strip()
    
    prompt = f"""请对以下文章标题和内容进行简短的总结，用2-3句话概括核心要点：

标题: {title}

内容: {content[:600]}

要求:
1. 用中文总结
2. 突出关键信息
3. 2-3句话，简洁明了"""
    
    try:
        result = subprocess.run(
            ["gemini", "-p", prompt],
            capture_output=True,
            text=True,
            timeout=15
        )
        if result.returncode == 0:
            summary = result.stdout.strip()[:200]
            with open(cache_file, 'w', encoding='utf-8') as f:
                f.write(summary)
            return summary
    except:
        pass
    
    return content[:150] + "..." if len(content) > 150 else content


def score_item(item: Dict) -> int:
    """打分排序"""
    text = (item.get("title", "") + " " + item.get("summary", "")).lower()
    score = 0
    if any(kw in text for kw in ["agent", "cursor", "coding", "programming", "应用", "工具"]):
        score += 20
    if any(kw in text for kw in ["product", "launch", "release", "工程", "workflow"]):
        score += 10
    if any(kw in text for kw in ["paper", "arxiv", "benchmark", "论文", "评估"]):
        score -= 5
    return score


def categorize(items: List[Dict]) -> Dict[str, List[Dict]]:
    """分类"""
    for item in items:
        item["score"] = score_item(item)
    items.sort(key=lambda x: x["score"], reverse=True)
    
    categories = {
        "Agent & 应用": [],
        "AI 编程工具": [],
        "产品与工程": [],
        "其他动态": []
    }
    
    for item in items:
        text = (item["title"] + " " + item.get("summary", "")).lower()
        if any(kw in text for kw in ["agent", "cursor", "工具", "产品", "应用"]):
            categories["Agent & 应用"].append(item)
        elif any(kw in text for kw in ["coding", "programming", "代码", "编程", "ide"]):
            categories["AI 编程工具"].append(item)
        elif any(kw in text for kw in ["product", "engineering", "工程", "workflow"]):
            categories["产品与工程"].append(item)
        else:
            categories["其他动态"].append(item)
    
    return {k: v for k, v in categories.items() if v}


def generate_html(items: List[Dict], date_str: str) -> str:
    """生成 HTML"""
    categories = categorize(items)
    total = len(items)
    
    categories_html = ""
    for cat_name, cat_items in categories.items():
        categories_html += generate_category_section(cat_name, cat_items[:10])
    
    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI 日报 - {date_str}</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {{
            --bg: #fafafa;
            --card: #ffffff;
            --accent: #3b82f6;
            --text: #1f2937;
            --text-secondary: #6b7280;
            --border: #e5e7eb;
            --shadow: 0 1px 3px rgba(0,0,0,0.1);
            --shadow-hover: 0 4px 12px rgba(0,0,0,0.15);
        }}
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg);
            color: var(--text);
            line-height: 1.6;
        }}
        .container {{
            max-width: 800px;
            margin: 0 auto;
            padding: 0 20px;
        }}
        header {{
            background: linear-gradient(135deg, #1e3a5f 0%, #2d5a87 100%);
            color: white;
            padding: 48px 0;
            margin-bottom: 32px;
        }}
        .header-content {{
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}
        h1 {{ font-size: 32px; font-weight: 700; margin-bottom: 8px; }}
        .subtitle {{ font-size: 14px; opacity: 0.8; }}
        .stats {{ text-align: right; }}
        .stats-value {{ font-size: 36px; font-weight: 700; color: #60a5fa; }}
        .stats-label {{ font-size: 12px; opacity: 0.7; }}
        .back-button {{
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: 14px;
            font-weight: 500;
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            padding: 8px 16px;
            background: rgba(255, 255, 255, 0.15);
            border-radius: 8px;
            transition: all 0.2s;
            margin-bottom: 16px;
        }}
        .back-button:hover {{ background: rgba(255, 255, 255, 0.25); }}
        .section {{ margin-bottom: 40px; }}
        .section-header {{
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 20px;
            padding-bottom: 12px;
            border-bottom: 2px solid var(--border);
        }}
        .section-title {{ font-size: 20px; font-weight: 600; }}
        .section-count {{
            margin-left: auto;
            background: var(--bg);
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 13px;
            color: var(--text-secondary);
        }}
        .news-list {{ display: flex; flex-direction: column; gap: 16px; }}
        .news-card {{
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 20px;
            box-shadow: var(--shadow);
            transition: all 0.2s ease;
        }}
        .news-card:hover {{
            box-shadow: var(--shadow-hover);
            transform: translateY(-2px);
        }}
        .news-meta {{
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 10px;
            font-size: 13px;
            color: var(--text-secondary);
        }}
        .news-source {{ color: var(--accent); font-weight: 600; }}
        .news-title {{
            font-size: 17px;
            font-weight: 600;
            margin-bottom: 10px;
            color: var(--text);
            line-height: 1.4;
        }}
        .news-summary {{
            font-size: 14px;
            color: var(--text-secondary);
            line-height: 1.7;
            margin-bottom: 14px;
        }}
        .news-link {{
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: 13px;
            font-weight: 500;
            color: var(--accent);
            text-decoration: none;
            padding: 8px 16px;
            background: rgba(59, 130, 246, 0.1);
            border-radius: 6px;
            transition: all 0.2s;
        }}
        .news-link:hover {{ background: var(--accent); color: white; }}
        footer {{
            border-top: 1px solid var(--border);
            padding: 24px 0;
            margin-top: 40px;
            text-align: center;
            font-size: 13px;
            color: var(--text-secondary);
        }}
        @media (max-width: 640px) {{
            .header-content {{ flex-direction: column; gap: 24px; text-align: center; }}
            .stats {{ text-align: center; }}
        }}
    </style>
</head>
<body>
    <header>
        <div class="container">
            <a href="ai-daily-archive.html" class="back-button">← 返回归档</a>
            <div class="header-content">
                <div>
                    <h1>🤖 AI 日报</h1>
                    <p class="subtitle">{date_str} · 近一周精选</p>
                </div>
                <div class="stats">
                    <div class="stats-value">{total}</div>
                    <div class="stats-label">条资讯</div>
                </div>
            </div>
        </div>
    </header>
    <main class="container">
        {categories_html}
    </main>
    <footer>
        <div class="container">
            <p>更新时间: {datetime.now().strftime('%Y-%m-%d %H:%M')}</p>
        </div>
    </footer>
</body>
</html>"""


def generate_category_section(name: str, items: List[Dict]) -> str:
    """生成分类区块"""
    cards_html = ""
    for item in items:
        date = item.get("published", "")[:16] if item.get("published") else ""
        ai_summary = item.get("ai_summary", "")
        if not ai_summary or len(ai_summary) < 10:
            ai_summary = item.get("summary", "")[:150] + "..."
        
        source = escape_html(item['source'])
        title = escape_html(item['title'])
        summary = escape_html(ai_summary)
        link = escape_html(item['link'])
        
        cards_html += f"""
        <article class="news-card">
            <div class="news-meta">
                <span class="news-source">{source}</span>
                <span>·</span>
                <span>{date}</span>
            </div>
            <h3 class="news-title">{title}</h3>
            <p class="news-summary">{summary}</p>
            <a href="{link}" class="news-link" target="_blank">阅读原文 →</a>
        </article>
        """
    
    return f"""
    <section class="section">
        <div class="section-header">
            <h2 class="section-title">{name}</h2>
            <span class="section-count">{len(items)} 条</span>
        </div>
        <div class="news-list">{cards_html}</div>
    </section>
    """


def update_archive_page(date_str: str, article_count: int):
    """更新归档页面 - 同一天只保留最新一篇"""
    try:
        archive_path = DOCS_DIR / "ai-daily-archive.html"
        if not archive_path.exists():
            return
        
        with open(archive_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        date_obj = datetime.strptime(date_str, "%Y-%m-%d")
        display_date = date_obj.strftime("%Y年%m月%d日")
        
        new_entry = f'''    {{
        "date": "{display_date}",
        "file": "ai-daily-{date_str}.html",
        "articles": {article_count}
    }}'''
        
        # 检查是否已有同一天的条目
        date_pattern = rf'{{[^}}]*"date":\s*"{display_date}"[^}}]*}}'
        existing_match = re.search(date_pattern, content)
        
        if existing_match:
            # 替换已有条目
            new_content = content[:existing_match.start()] + new_entry + content[existing_match.end():]
            print(f"  ✓ 已更新当天归档: {display_date} (覆盖旧数据)")
        else:
            # 添加新条目到开头
            match = re.search(r'(const archives = \[)', content)
            if match:
                insert_pos = match.end()
                if content[insert_pos:insert_pos+1] == ']':
                    new_content = content[:insert_pos] + '\n' + new_entry + '\n' + content[insert_pos:]
                else:
                    new_content = content[:insert_pos] + '\n' + new_entry + ',' + content[insert_pos:]
                print(f"  ✓ 已添加新归档: {display_date}")
            else:
                print(f"  ⚠️  未找到 archives 数组")
                return
        
        with open(archive_path, 'w', encoding='utf-8') as f:
            f.write(new_content)
            
    except Exception as e:
        print(f"  ⚠️  更新归档失败: {e}")


def run():
    """运行日报生成"""
    date_str = datetime.now().strftime("%Y-%m-%d")
    week_ago = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")
    
    print(f"\n{'='*60}")
    print(f"🤖 AI 日报生成")
    print(f"{'='*60}")
    print(f"\n📅 抓取范围: {week_ago} ~ {date_str}\n")
    
    sources = load_sources()
    print(f"📡 开始抓取 {len(sources)} 个信源...\n")
    
    all_items = []
    failed_sources = []
    
    for source in sources:
        print(f"  {source['name']}")
        content = fetch(source['url'])
        if content:
            items = parse_rss(content, source, max_items=3)
            all_items.extend(items)
            print(f"    ✓ {len(items)} 条")
        else:
            failed_sources.append(source['name'])
            print(f"    ✗ 获取失败")
    
    print(f"\n{'='*60}")
    print(f"📊 成功: {len(all_items)} 条")
    if failed_sources:
        print(f"⚠️  失败: {len(failed_sources)} 个信源")
    print(f"{'='*60}")
    
    if not all_items:
        print("⚠️ 未抓取到数据")
        return None
    
    # 生成 AI 总结
    print("\n🤖 生成 AI 总结...")
    for i, item in enumerate(sorted(all_items, key=score_item, reverse=True)[:15], 1):
        print(f"  [{i}/15] {item['title'][:40]}...")
        item["ai_summary"] = ai_summarize(item["title"], item["summary"])
    
    # 保存数据
    json_path = DATA_DIR / f"ai-news-{date_str}.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump({
            "date": date_str,
            "total": len(all_items),
            "failed_sources": failed_sources,
            "items": all_items
        }, f, ensure_ascii=False, indent=2)
    print(f"\n💾 数据: {json_path}")
    
    # 生成 HTML
    print("🎨 生成 HTML...")
    html = generate_html(all_items, date_str)
    
    # 保存文件
    html_path = OUTPUT_DIR / f"ai-daily-{date_str}.html"
    docs_path = DOCS_DIR / f"ai-daily-{date_str}.html"
    docs_latest_path = DOCS_DIR / "ai-daily-latest.html"
    
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html)
    with open(docs_path, "w", encoding="utf-8") as f:
        f.write(html)
    with open(docs_latest_path, "w", encoding="utf-8") as f:
        f.write(html)
    
    print(f"✓ {html_path}")
    print(f"✓ {docs_path}")
    print(f"✓ {docs_latest_path}")
    
    # 更新归档
    print("\n📚 更新历史日报归档...")
    update_archive_page(date_str, len(all_items))
    
    print(f"\n{'='*60}")
    print("✅ AI 日报生成完成!")
    print(f"{'='*60}\n")
    
    return date_str


if __name__ == "__main__":
    run()
