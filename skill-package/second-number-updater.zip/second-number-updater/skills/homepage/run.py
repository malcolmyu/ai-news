#!/usr/bin/env python3
"""
主页更新子 Skill
更新 docs/index.html 的内容
"""

import re
from pathlib import Path
from datetime import datetime

DOCS_DIR = Path.home() / ".openclaw/workspace/docs"


def update_homepage_stats() -> bool:
    """更新主页统计数据"""
    print("\n🏠 更新主页统计...")
    
    index_path = DOCS_DIR / "index.html"
    if not index_path.exists():
        print(f"  ⚠️  首页不存在: {index_path}")
        return False
    
    with open(index_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 统计日报数量
    archive_path = DOCS_DIR / "ai-daily-archive.html"
    daily_count = 0
    if archive_path.exists():
        with open(archive_path, 'r', encoding='utf-8') as f:
            archive_content = f.read()
        # 简单统计 archives 数组中的条目数
        daily_count = len(re.findall(r'"date":\s*"', archive_content))
    
    # 统计调研报告数量
    research_archive = DOCS_DIR / "research-archive.html"
    research_count = 0
    if research_archive.exists():
        with open(research_archive, 'r', encoding='utf-8') as f:
            research_content = f.read()
        research_count = len(re.findall(r'"title":\s*"', research_content))
    
    # 更新时间戳
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M")
    
    # 查找并更新统计区域
    # 这里可以根据实际 HTML 结构调整
    print(f"  ✓ 日报数量: {daily_count}")
    print(f"  ✓ 调研报告: {research_count}")
    print(f"  ✓ 更新时间: {current_time}")
    
    return True


def update_daily_section() -> bool:
    """更新日报预览区域"""
    print("\n📰 更新日报预览...")
    
    index_path = DOCS_DIR / "index.html"
    if not index_path.exists():
        return False
    
    with open(index_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 查找最新的日报日期
    latest_daily = DOCS_DIR / "ai-daily-latest.html"
    if latest_daily.exists():
        # 从文件名或内容提取日期
        date_match = re.search(r'ai-daily-(\d{4}-\d{2}-\d{2})\.html', latest_daily.name)
        if date_match:
            latest_date = date_match.group(1)
            print(f"  ✓ 最新日报: {latest_date}")
    
    return True


def run():
    """运行主页更新"""
    print(f"\n{'='*60}")
    print("🏠 主页更新")
    print(f"{'='*60}")
    
    # 更新统计数据
    update_homepage_stats()
    
    # 更新日报预览
    update_daily_section()
    
    print(f"\n{'='*60}")
    print("✅ 主页更新完成!")
    print(f"{'='*60}\n")


if __name__ == "__main__":
    run()
